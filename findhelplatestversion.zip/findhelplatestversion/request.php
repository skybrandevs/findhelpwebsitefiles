  <?php
  

$con = mysqli_connect('localhost','findhelp_admin','Mylyfe2893');

  if(!$con) 
  {

    echo '   
    
    
    
    




<div style=" margin-bottom:-50px;
    font-family:Courier New, Courier, monospace;
    text-align:center;
    color:grey; text-align:center;"> <span> An error occured </span> </div>
    
    
    
    
    
    ';


  }

if(!mysqli_select_db($con,'findhelp_request'))
{
echo'

  


  <div style="text-align:center; margin:150px; "> 
  
   <img src="sike.svg"  width="150px"> 
  
  </div>
  
  


<div style=" margin-bottom:-50px;
    font-family:Courier New, Courier, monospace;
    text-align:center;
    color:grey; text-align:center;"> <span> Ooppss!!!! something went wrong </span> </div> ';
} 




$firstname = $_POST['firstname'];
$secondname = $_POST['secondname'];
$email = $_POST['email'];
$phnenum = $_POST['phnenum'];
$services = $_POST['services'];
  	$trn_date = date("Y-m-d H:i:s");
  	
  	 
$sql = "INSERT INTO submit_request (firstname,secondname,email,phnenum,services,trn_date) VALUES ('$firstname','$secondname','$email','$phnenum','$services','$trn_date')";



if(!mysqli_query($con,$sql))
{

		echo '<div style=" margin-bottom:-50px;
    font-family:Courier New, Courier, monospace;
    text-align:center;
    color:grey; text-align:center;"  <span>Sorry We encountered an error. Please try again later </span> </div>';


    
}


else{
    
    

   echo ' 
  
  <html lang="eng">
  <head>
  
 <meta http-equiv="refresh" content="8;url=howitworks.html">
  
   <meta charset="UTF-8">
 
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no,user-scalable=0  ">
 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  


  <title> We have recieved your request </title>
  
    <meta name="theme-color" content="#02AEEE">
  
  
  
  
  <style>

.vertically {
 height: 500px;	
 overflow: hidden;
 position: relative;
}

.vertically .inner {
 position: absolute;
 width: 100%;
 height: 70%;
 
 /* Starting position */
 -moz-transform:translateY(40%);
 -webkit-transform:translateY(40%);	
 transform:translateY(40%);
 /* Apply animation to this element */	
 -moz-animation: vertically 5s linear infinite alternate;
 -webkit-animation: vertically 5s linear infinite alternate;
 animation: vertically 5s linear infinite alternate;
}
/* Move it (define the animation) */
@-moz-keyframes vertically {
 0%   { -moz-transform: translateY(70%); }
 100% { -moz-transform: translateY(0%); }
}
@-webkit-keyframes vertically {
 0%   { -webkit-transform: translateY(70%); }
 100% { -webkit-transform: translateY(0%); }
}
@keyframes vertically {
 0%   { 
 -moz-transform: translateY(70%); /* Browser bug fix */
 -webkit-transform: translateY(70%); /* Browser bug fix */
 transform: translateY(70%); 		
 }
 100% { 
 -moz-transform: translateY(0%); /* Browser bug fix */
 -webkit-transform: translateY(0%); /* Browser bug fix */
 transform: translateY(0%); 
 }
}


.dothis{
    
    margin-bottom:-50px;
    font-family:Courier New, Courier, monospace;
    text-align:center;
    color:grey;
}


#img{
    
     width:150px;
     margin:70px;
    
}



@media only screen and (max-width:600px) {
    
    #img{
    
     width:100px;
     margin:70px;
     height:auto;
    
}
    
    
    
}


   /*for scrollerbar*/
     /* width */
     ::-webkit-scrollbar {
        width: 4px;
    }
    
    /* Track */
    ::-webkit-scrollbar-track {
        background:white; 
    }
     
    /* Handle */
    ::-webkit-scrollbar-thumb {
        background:#02AEEE; 
    }
    
    /* Handle on hover */
    ::-webkit-scrollbar-thumb:hover {
        background:#02AEEE; 
    }
    
    .d{
        
        font-family:inherit;
        font-size:13px;
        font-weight:bold;
        
        
    }


</style>

  
  
  
  </head>
  
  
  
  <body>
  
  
  <div class="vertically">
<div class="inner">

  <div style="text-align:center;"> 
  
   <img src="sike.svg" id="img" class="img-fluid" > 
  
  </div>
  
  
</div>
</div>

  
    
          <div class="dothis"> 
  
<span><h4 class="d"> Awesome you </h4> </span>    <span> <h6 class="d"> we have got your Request in our box , Our representative would call you shortly.  </h6> </span>



  
  
  </div> 
  
  
  
  
  </body>
  
  
  
  </html>
  
  
  
  
  
  ';
  

 
 

 
}


?>
